import { SimpleAdminPanel } from '@/components/SimpleAdminPanel'

export default function AdminPage() {
  return <SimpleAdminPanel />
}